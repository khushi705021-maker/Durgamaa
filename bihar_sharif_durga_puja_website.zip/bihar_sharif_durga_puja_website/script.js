const places = [
  {
    id: "bhaisasur",
    name: "Bhaisasur Chauraha",
    category: "theme",
    label: "CAVE-INSPIRED PANDAL",
    location: "Bhaisasur Chauraha, Bihar Sharif, Nalanda",
    image: "images/bhaisasur-pandal.jpg",
    short: "A memorable Amarnath-cave-inspired pandal was reported here, blending dramatic rock-like scenery and devotional displays.",
    description: "A 2022 news report described a cave-style pandal near Bhaisasur Chauraha, inspired by the Amarnath cave. The report mentioned colourful lighting, a large Kali idol and a route with steps leading towards a Baba Barfani display. This is a historical theme reference, not confirmation of the current year's design.",
    materials: "The published report describes a cave-like structure but does not reliably specify every construction material used for the idol or pandal. Treat the current idol materials and structure as unverified until the organising committee confirms them.",
    map: "https://www.google.com/maps/search/?api=1&query=Bhaisasur+Chauraha+Bihar+Sharif",
    source: "https://navbharattimes.indiatimes.com/state/bihar/nalanda/durga-puja-pandal-bhaisasur-chauraha-bihar-sharif-nalanda-watch-video/articleshow/94599799.cms"
  },
  {
    id: "pulpar",
    name: "Pulpar Durga Pandal",
    category: "theme",
    label: "FORT-INSPIRED DESIGN",
    location: "Pulpar, Bihar Sharif, Nalanda",
    image: "images/pulpar-pandal.jpg",
    short: "Pulpar has been reported for elaborate themed pandal designs, including a fort-inspired structure in an earlier year.",
    description: "A Nalanda Live report from 2018 described Pulpar's pandal as inspired by Chittorgarh Fort. It reported decorative levels and detailed window-like openings. Pandal themes change annually, so this should be read as an example of the area's creative tradition—not the current year's theme.",
    materials: "The 2018 report mentioned bamboo, thermocol sheets and wooden supports for that year's fort-inspired structure. These are historical details only and should not be assumed to describe a newer pandal or the idol itself.",
    map: "https://www.google.com/maps/search/?api=1&query=Pulpar+Bihar+Sharif",
    source: "https://www.nalandalive.com/bihar-sharif/durga-pooja-pandal-in-pulpar-biharsharif/"
  },
  {
    id: "mohaddi",
    name: "Mohaddi Nagar",
    category: "theme",
    label: "FAIRY-INSPIRED THEME",
    location: "Mohaddi Nagar, Amber, Bihar Sharif",
    image: "images/mohaddi-nagar.jpg",
    short: "A local pandal in Mohaddi Nagar; an earlier report described a fairy-world-inspired design with colourful lights.",
    description: "A 2022 report described a roughly 40-foot pandal in Mohiuddinnagar with a fairy-world look and a Durga idol riding a lion. The report gives a useful glimpse into local theme-making, but it does not establish the current year's design.",
    materials: "The report did not provide a verified list of materials used for the idol or the full structure. Ask the local puja committee for the current year's artisan and material details.",
    map: "https://www.google.com/maps/search/?api=1&query=Mohaddi+Nagar+Durga+Pandal+Bihar+Sharif",
    source: "https://navbharattimes.indiatimes.com/state/bihar/nalanda/durga-puja-pandal-mohiuddinnagar-nalanda-fairy-look-40-feet-height-watch-video/videoshow/94600001.cms"
  },
  {
    id: "nalapath",
    name: "Nala Road",
    category: "theme",
    label: "ARCHITECTURAL THEMES",
    location: "Nala Road, Bihar Sharif, Nalanda",
    image: "images/nala-road.jpg",
    short: "Nala Road has appeared in local Durga Puja coverage for ambitious, architecture-inspired pandal concepts.",
    description: "A 2022 report from Nalanda mentioned a Nala Road pandal modelled on India's Parliament building. It is included as a historical example of how familiar architecture can inspire local festival design.",
    materials: "The cited report does not give enough verified detail to state the current structure's material or idol-making process. Details should be confirmed with the committee for the relevant year.",
    map: "https://www.google.com/maps/search/?api=1&query=Nala+Road+Bihar+Sharif",
    source: "https://www.abplive.com/states/bihar/durga-puja-2022-amarnath-cave-like-design-in-nalanda-bihar-in-durga-puja-also-attractive-pandals-and-lights-ann-2229692"
  },
  {
    id: "amber",
    name: "Amber Devi Asthan",
    category: "darshan",
    label: "TEMPLE & DARSHAN",
    location: "Dak Bangla More, Kaghzi Mohalla, Bihar Sharif",
    image: "images/amber-devi.jpg",
    short: "A Maa Durga/Devi temple in central Bihar Sharif, a useful location for devotees looking for darshan.",
    description: "Amber Devi Asthan is listed as a Devi temple in the Dak Bangla More/Kaghzi Mohalla area. This card focuses on the place of worship rather than claiming it is a temporary themed pandal.",
    materials: "Temple architecture and permanent shrine details differ from temporary festival pandals. No verified information was found for the materials used for a specific seasonal idol here; check with the temple or local organisers.",
    map: "https://www.google.com/maps/search/?api=1&query=Amber+Devi+Asthan+Bihar+Sharif",
    source: "https://www.google.com/maps/search/?api=1&query=Amber+Devi+Asthan+Bihar+Sharif"
  },
  {
    id: "navdurga",
    name: "Nav Durga",
    category: "darshan",
    label: "LOCAL DEVOTION",
    location: "Chaukhandi Par Road, Saluganj Mohalla, Bihar Sharif",
    image: "images/nav-durga.jpg",
    short: "A neighbourhood place of worship associated with Durga Puja and seasonal devotion.",
    description: "Nav Durga is listed in the Chaukhandi Par Road/Saluganj Mohalla area of Bihar Sharif. The listing identifies it as a local worship site; temporary decorations and festival arrangements may vary each year.",
    materials: "Specific idol materials, artisan details and the current seasonal pandal structure are not confirmed in the public listing. Add verified details after speaking with the local committee.",
    map: "https://www.google.com/maps/search/?api=1&query=Nav+Durga+Chaukhandi+Par+Bihar+Sharif",
    source: "https://www.google.com/maps/search/?api=1&query=Nav+Durga+Chaukhandi+Par+Bihar+Sharif"
  }
];

const grid = document.getElementById("pandalGrid");
const modal = document.getElementById("detailModal");
const intro = document.getElementById("introScreen");
const site = document.getElementById("mainSite");

function renderCards(filter = "all") {
  const visible = places.filter(place => filter === "all" || place.category === filter);
  grid.innerHTML = visible.map((place, index) => `
    <article class="pandal-card">
      <div class="card-image">
        <img src="${place.image}" alt="${place.name} Durga Puja" loading="lazy"
          onerror="this.style.display='none'; this.parentElement.classList.add('image-missing');">
        <span class="card-number">0${index + 1} / SHAKTI AAGMAN</span>
        <span class="card-type">${place.label}</span>
      </div>
      <div class="card-content">
        <h3>${place.name}</h3>
        <div class="card-location">⌖ <span>${place.location}</span></div>
        <p>${place.short}</p>
        <div class="card-footer">
          <span>EXPLORE THE STORY</span>
          <button class="know-more" data-id="${place.id}">KNOW MORE ↗</button>
        </div>
      </div>
    </article>
  `).join("");
  grid.querySelectorAll(".know-more").forEach(button => {
    button.addEventListener("click", () => openDetails(button.dataset.id));
  });
}

function openDetails(id) {
  const place = places.find(item => item.id === id);
  if (!place) return;
  document.getElementById("modalImage").src = place.image;
  document.getElementById("modalImage").alt = place.name;
  document.getElementById("modalCategory").textContent = place.label;
  document.getElementById("modalTitle").textContent = place.name;
  document.getElementById("modalLocation").textContent = "⌖ " + place.location;
  document.getElementById("modalDescription").textContent = place.description;
  document.getElementById("modalMaterials").textContent = place.materials;
  document.getElementById("mapLink").href = place.map;
  document.getElementById("sourceLink").href = place.source;
  modal.classList.add("open");
  document.body.style.overflow = "hidden";
  document.getElementById("modalClose").focus();
}

function closeDetails() {
  modal.classList.remove("open");
  document.body.style.overflow = "";
}

document.getElementById("enterButton").addEventListener("click", () => {
  intro.classList.add("hidden");
  site.classList.add("visible");
  site.setAttribute("aria-hidden", "false");
  window.setTimeout(() => document.getElementById("home").scrollIntoView({behavior: "smooth"}), 150);
});

document.querySelectorAll(".filter-chip").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".filter-chip").forEach(chip => chip.classList.remove("active"));
    button.classList.add("active");
    renderCards(button.dataset.filter);
  });
});

document.getElementById("modalClose").addEventListener("click", closeDetails);
modal.addEventListener("click", event => { if (event.target === modal) closeDetails(); });
document.addEventListener("keydown", event => { if (event.key === "Escape") closeDetails(); });

const menuToggle = document.getElementById("menuToggle");
const navMenu = document.getElementById("navMenu");
menuToggle.addEventListener("click", () => navMenu.classList.toggle("open"));
navMenu.querySelectorAll("a").forEach(link => link.addEventListener("click", () => navMenu.classList.remove("open")));

renderCards();
