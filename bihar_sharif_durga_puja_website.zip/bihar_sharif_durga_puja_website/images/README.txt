Add your own Durga Maa idol and pandal photos to this folder, using these exact filenames:
- hero-durga.jpg
- bhaisasur-pandal.jpg
- pulpar-pandal.jpg
- mohaddi-nagar.jpg
- nala-road.jpg
- amber-devi.jpg
- nav-durga.jpg

The website includes historical theme references and map searches, not verified current-year materials for every location. Use photos you took yourself or images you have permission to use. If an image is missing, the card still shows its text and gradient background.
